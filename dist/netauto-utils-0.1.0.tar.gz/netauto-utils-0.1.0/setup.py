# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['netauto_utils']

package_data = \
{'': ['*']}

install_requires = \
['netaddr>=0.8.0,<0.9.0',
 'netmiko>=4.1.2,<5.0.0',
 'paramiko>=2.12.0,<3.0.0',
 'rich>=13.0.1,<14.0.0']

setup_kwargs = {
    'name': 'netauto-utils',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Network Automation Utilities\n\nThis package contains a variety of modules. Some are for general Python tasks like file conversions, others are for aiding Network Engineering  Automation. I have and still use many of these utilities as an Automation Engineer. \n\nOffical documentation can be found [here](https://ADD-NEW-LINK).\n\n## Installation\n\n\n\n`poetry add cwe_tools`.\n\nIf you can *not* install, clone the repository & run `poetry install` to install the package. \n\n_NOTE:_ Other package managers such as `pip` can also be used for installation.\n\nYou can also clone and install the package locally with:\n\n```bash\n$ git clone (https://ADD-NEW-LINK)\n$ cd cwe_tools\n$ poetry install  # Use --no-dev if you don\'t want development dependencies\n```\n\n## Quick Start\n\nExample of using a utility in the `data_converter` module to convert a Python object to a YAML file:\n\nSee source code for more info on the utilities and their associated parameters.\n\n```python\n# Import module\n>>> \n>>> from netauto_utils import data_converter\n>>> \n>>> python_obj = {\n...     "Yaml Data": [\n...         {"a": 1, "b": 2},\n...         {"c": 3, "d": 4},\n...         {"e": 5, "f": 6},\n...     ]\n... }\n>>> \n>>> write_file = True\n>>> \n>>> filename = \'my_new_yaml_file.yml\'\n>>> \n>>> \n>>> print(data_converter.python_to_yaml(python_obj, write_file, filename))\nmy_new_yaml_file.yml has been created! 👍\n\nYaml Data:\n  - a: 1\n    b: 2\n  - c: 3\n    d: 4\n  - e: 5\n    f: 6\n\n>>>\n```\nThe new YAML file generated `my_new_yaml_file.yml`.\n```\n---\nYaml Data:\n  - a: 1\n    b: 2\n  - c: 3\n    d: 4\n  - e: 5\n    f: 6\n\n```\n## Cutting a New Release\n1. Checkout develop branch - ensure you have the latest commits by running git pull\n2. Create new branch - git checkout -b <new-branch>\n\nPerform the following operations:\n- Run poetry version <major/minor/patch> to update version in pyproject.toml\n- Edit CHANGELOG.md - Update for new version with changes included in new version\n- Run poetry update to update Python dependencies\n- Commit all changes - push branch to GitLab\n- Open new MR for your new branch into master\n- After the merge is completed, cut a new tag (Repository > Tags > Name: vX.X.X)\n- Open new MR from master into develop to sync branches (master will not be deleted).\n\n',
    'author': 'ns03444',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
